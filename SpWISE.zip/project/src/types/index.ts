export interface SpacecraftConfig {
  geometry: string;
  material: string;
  size: number;
  orientation: { x: number; y: number; z: number };
  components: SpacecraftComponent[];
  mesh: Mesh | null;
}

export interface SpacecraftComponent {
  id: string;
  type: 'solar_panel' | 'antenna' | 'thruster' | 'sensor' | 'structure';
  position: { x: number; y: number; z: number };
  dimensions: { width: number; height: number; depth: number };
  material: string;
  properties: Record<string, any>;
}

export interface Mesh {
  vertices: number[];
  faces: number[];
  normals: number[];
  materials: string[];
}

export interface EnvironmentConfig {
  plasmaDensity: number;
  temperature: number;
  velocity: number;
  magneticField: number;
  solarActivity: number;
  location: string;
  altitude: number;
}

export interface SolverConfig {
  pic: {
    enabled: boolean;
    timestep: number;
    particles: number;
  };
  fem: {
    enabled: boolean;
    elements: number;
    convergence: number;
  };
  thermal: {
    enabled: boolean;
    conductivity: number;
    emissivity: number;
  };
  radiation: {
    enabled: boolean;
    shielding: number;
    materials: string[];
  };
}

export interface SimulationResults {
  surfaceCharge: number;
  currentDensity: number;
  fieldStrength: number;
  temperature: number;
  radiationDose: number;
  thermalStress: number;
  fieldData?: Float32Array;
  particleData?: ParticleData[];
  thermalMap?: ThermalData[];
}

export interface ParticleData {
  id: number;
  position: { x: number; y: number; z: number };
  velocity: { x: number; y: number; z: number };
  charge: number;
  mass: number;
  type: 'electron' | 'ion' | 'neutral';
}

export interface ThermalData {
  nodeId: number;
  temperature: number;
  heatFlux: number;
}

export interface AIConfig {
  fastMode: boolean;
  confidence: number;
  recommendations: AIRecommendation[];
}

export interface AIRecommendation {
  type: 'warning' | 'optimization' | 'suggestion';
  message: string;
  confidence: number;
  action?: string;
}

export interface SimulationState {
  isRunning: boolean;
  mode: 'realtime' | 'batch' | 'ai_fast';
  spacecraft: SpacecraftConfig;
  environment: EnvironmentConfig;
  solvers: SolverConfig;
  results: SimulationResults;
  ai: AIConfig;
}

export interface SpaceWeatherData {
  solarWind: {
    speed: number;
    density: number;
    temperature: number;
    magneticField: { bx: number; by: number; bz: number };
  };
  geomagnetic: {
    kpIndex: number;
    apIndex: number;
    dstIndex: number;
  };
  solar: {
    f107: number;
    sunspotNumber: number;
    solarFlares: SolarFlare[];
  };
  radiation: {
    protonFlux: number;
    electronFlux: number;
    cosmicRays: number;
  };
  timestamp: Date;
}

export interface SolarFlare {
  class: string;
  intensity: number;
  timestamp: Date;
  duration: number;
}