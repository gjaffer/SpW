import React from 'react';
import { Thermometer, Wind, Zap, Magnet } from 'lucide-react';

interface EnvironmentProps {
  environment: {
    plasmaDensity: number;
    temperature: number;
    velocity: number;
    magneticField: number;
    solarActivity: number;
  };
  onUpdate: (environment: any) => void;
}

export const EnvironmentPanel: React.FC<EnvironmentProps> = ({ environment, onUpdate }) => {
  const parameters = [
    {
      key: 'plasmaDensity',
      label: 'Plasma Density',
      icon: Zap,
      unit: 'particles/cm³',
      min: 1e3,
      max: 1e8,
      value: environment.plasmaDensity,
      displayValue: (environment.plasmaDensity / 1e6).toFixed(2),
      displayUnit: '×10⁶ /cm³',
      color: 'blue'
    },
    {
      key: 'temperature',
      label: 'Electron Temperature',
      icon: Thermometer,
      unit: 'K',
      min: 100,
      max: 50000,
      value: environment.temperature,
      displayValue: environment.temperature.toLocaleString(),
      displayUnit: 'K',
      color: 'red'
    },
    {
      key: 'velocity',
      label: 'Plasma Velocity',
      icon: Wind,
      unit: 'km/s',
      min: 50,
      max: 1000,
      value: environment.velocity,
      displayValue: environment.velocity.toString(),
      displayUnit: 'km/s',
      color: 'green'
    },
    {
      key: 'magneticField',
      label: 'Magnetic Field',
      icon: Magnet,
      unit: 'nT',
      min: 10,
      max: 500,
      value: environment.magneticField,
      displayValue: environment.magneticField.toString(),
      displayUnit: 'nT',
      color: 'purple'
    }
  ];

  const presets = [
    {
      name: 'Low Earth Orbit (LEO)',
      description: 'Typical conditions at 300-800 km altitude',
      params: { plasmaDensity: 1e6, temperature: 1000, velocity: 300, magneticField: 50 }
    },
    {
      name: 'Geostationary Orbit (GEO)',
      description: 'Conditions at 35,786 km altitude',
      params: { plasmaDensity: 1e4, temperature: 10000, velocity: 400, magneticField: 100 }
    },
    {
      name: 'Solar Wind',
      description: 'Interplanetary space conditions',
      params: { plasmaDensity: 5e3, temperature: 100000, velocity: 500, magneticField: 5 }
    },
    {
      name: 'Magnetospheric Storm',
      description: 'Enhanced space weather conditions',
      params: { plasmaDensity: 1e7, temperature: 50000, velocity: 800, magneticField: 200 }
    }
  ];

  const updateParameter = (key: string, value: number) => {
    onUpdate({
      ...environment,
      [key]: value
    });
  };

  return (
    <div className="h-full p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold text-white mb-2">Plasma Environment</h2>
        <p className="text-gray-400">Configure space environment parameters for simulation</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100%-6rem)]">
        {/* Parameter Controls */}
        <div className="space-y-6">
          <h3 className="text-lg font-medium text-white mb-4">Environment Parameters</h3>
          
          {parameters.map((param) => {
            const Icon = param.icon;
            const colorClasses = {
              blue: 'from-blue-500 to-blue-600',
              red: 'from-red-500 to-red-600',
              green: 'from-green-500 to-green-600',
              purple: 'from-purple-500 to-purple-600'
            };

            return (
              <div key={param.key} className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Icon className={`w-5 h-5 text-${param.color}-400`} />
                    <span className="font-medium text-white">{param.label}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold text-white">
                      {param.displayValue}
                    </div>
                    <div className="text-xs text-gray-400">{param.displayUnit}</div>
                  </div>
                </div>
                
                <input
                  type="range"
                  min={param.min}
                  max={param.max}
                  value={param.value}
                  onChange={(e) => updateParameter(param.key, parseFloat(e.target.value))}
                  className={`w-full h-2 bg-gradient-to-r ${colorClasses[param.color as keyof typeof colorClasses]} rounded-lg appearance-none cursor-pointer`}
                />
                
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>{param.min.toLocaleString()}</span>
                  <span>{param.max.toLocaleString()}</span>
                </div>
              </div>
            );
          })}

          {/* Solar Activity */}
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <div className="flex items-center justify-between mb-3">
              <span className="font-medium text-white">Solar Activity Level</span>
              <div className="text-right">
                <div className="text-lg font-semibold text-white">
                  {(environment.solarActivity * 100).toFixed(0)}%
                </div>
                <div className="text-xs text-gray-400">Activity Index</div>
              </div>
            </div>
            
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={environment.solarActivity}
              onChange={(e) => updateParameter('solarActivity', parseFloat(e.target.value))}
              className="w-full h-2 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-lg appearance-none cursor-pointer"
            />
            
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Quiet</span>
              <span>Extreme</span>
            </div>
          </div>
        </div>

        {/* Environment Presets */}
        <div>
          <h3 className="text-lg font-medium text-white mb-4">Environment Presets</h3>
          <div className="space-y-3">
            {presets.map((preset, index) => (
              <div
                key={index}
                className="bg-gray-800 rounded-lg p-4 border border-gray-700 hover:border-gray-600 cursor-pointer transition-colors"
                onClick={() => onUpdate({ ...environment, ...preset.params })}
              >
                <h4 className="font-medium text-white mb-1">{preset.name}</h4>
                <p className="text-sm text-gray-400 mb-3">{preset.description}</p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="text-gray-500">
                    Density: <span className="text-blue-400">{(preset.params.plasmaDensity / 1e6).toFixed(1)}M /cm³</span>
                  </div>
                  <div className="text-gray-500">
                    Temp: <span className="text-red-400">{preset.params.temperature.toLocaleString()} K</span>
                  </div>
                  <div className="text-gray-500">
                    Velocity: <span className="text-green-400">{preset.params.velocity} km/s</span>
                  </div>
                  <div className="text-gray-500">
                    B-field: <span className="text-purple-400">{preset.params.magneticField} nT</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Real-time Conditions Display */}
          <div className="mt-6 bg-gray-800 rounded-lg p-4 border border-gray-700">
            <h4 className="font-medium text-white mb-3">Current Conditions</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Debye Length:</span>
                <span className="text-blue-400">
                  {(Math.sqrt(8.85e-12 * environment.temperature * 1.38e-23 / (environment.plasmaDensity * 1e6 * 1.6e-19**2)) * 1000).toFixed(2)} mm
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Plasma Frequency:</span>
                <span className="text-green-400">
                  {(Math.sqrt(environment.plasmaDensity * 1e6 * 1.6e-19**2 / (9.11e-31 * 8.85e-12)) / (2 * Math.PI) / 1e6).toFixed(1)} MHz
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Gyrofrequency:</span>
                <span className="text-purple-400">
                  {(1.6e-19 * environment.magneticField * 1e-9 / (2 * Math.PI * 9.11e-31) / 1e6).toFixed(1)} MHz
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};