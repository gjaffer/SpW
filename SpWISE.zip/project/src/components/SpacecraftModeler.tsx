import React, { useState, useRef } from 'react';
import { Upload, Download, RotateCcw, Plus, Trash2, Settings, Box, Zap } from 'lucide-react';
import { SpacecraftConfig, SpacecraftComponent } from '../types';

interface SpacecraftModelerProps {
  spacecraft: SpacecraftConfig;
  onUpdate: (spacecraft: SpacecraftConfig) => void;
}

export const SpacecraftModeler: React.FC<SpacecraftModelerProps> = ({ spacecraft, onUpdate }) => {
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);
  const [showAddComponent, setShowAddComponent] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const geometryTypes = [
    { id: 'satellite', label: 'CubeSat', description: '1U-6U standardized satellite' },
    { id: 'probe', label: 'Deep Space Probe', description: 'Interplanetary exploration vehicle' },
    { id: 'station', label: 'Space Station Module', description: 'Large pressurized module' },
    { id: 'lander', label: 'Planetary Lander', description: 'Surface exploration vehicle' },
    { id: 'custom', label: 'Custom CAD Import', description: 'STEP/IGES/OBJ file import' }
  ];

  const materials = [
    { id: 'aluminum', label: 'Aluminum 6061-T6', conductivity: 'High', charging: 'Low', density: 2.7 },
    { id: 'carbon', label: 'Carbon Fiber Composite', conductivity: 'Medium', charging: 'Medium', density: 1.6 },
    { id: 'kapton', label: 'Kapton Polyimide', conductivity: 'Low', charging: 'High', density: 1.4 },
    { id: 'gold', label: 'Gold Plated', conductivity: 'Very High', charging: 'Very Low', density: 19.3 },
    { id: 'titanium', label: 'Titanium Ti-6Al-4V', conductivity: 'Medium', charging: 'Low', density: 4.4 }
  ];

  const componentTypes = [
    { id: 'solar_panel', label: 'Solar Panel', icon: '☀️' },
    { id: 'antenna', label: 'Antenna', icon: '📡' },
    { id: 'thruster', label: 'Thruster', icon: '🚀' },
    { id: 'sensor', label: 'Sensor', icon: '👁️' },
    { id: 'structure', label: 'Structure', icon: '🔧' }
  ];

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Simulate CAD file processing
      const reader = new FileReader();
      reader.onload = (e) => {
        // In a real implementation, this would parse STEP/IGES/OBJ files
        console.log('Processing CAD file:', file.name);
        onUpdate({
          ...spacecraft,
          geometry: 'custom',
          mesh: {
            vertices: new Array(1000).fill(0).map(() => Math.random() * 2 - 1),
            faces: new Array(500).fill(0).map((_, i) => i),
            normals: new Array(1000).fill(0).map(() => Math.random() * 2 - 1),
            materials: ['imported_material']
          }
        });
      };
      reader.readAsArrayBuffer(file);
    }
  };

  const addComponent = (type: string) => {
    const newComponent: SpacecraftComponent = {
      id: `${type}_${Date.now()}`,
      type: type as any,
      position: { x: 0, y: 0, z: 0 },
      dimensions: { width: 1, height: 1, depth: 0.1 },
      material: 'aluminum',
      properties: {}
    };

    onUpdate({
      ...spacecraft,
      components: [...spacecraft.components, newComponent]
    });
    setShowAddComponent(false);
  };

  const removeComponent = (componentId: string) => {
    onUpdate({
      ...spacecraft,
      components: spacecraft.components.filter(c => c.id !== componentId)
    });
    setSelectedComponent(null);
  };

  const updateComponent = (componentId: string, updates: Partial<SpacecraftComponent>) => {
    onUpdate({
      ...spacecraft,
      components: spacecraft.components.map(c => 
        c.id === componentId ? { ...c, ...updates } : c
      )
    });
  };

  return (
    <div className="h-full flex">
      {/* 3D Viewer */}
      <div className="flex-1 p-6">
        <div className="bg-black rounded-lg h-full relative border border-gray-600 overflow-hidden">
          {/* 3D Visualization Area */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="relative">
                {/* Main Spacecraft Body */}
                <div className="w-40 h-40 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg mx-auto mb-4 flex items-center justify-center relative transform rotate-12 hover:rotate-0 transition-transform duration-500">
                  <Box className="w-16 h-16 text-white" />
                  
                  {/* Components Visualization */}
                  {spacecraft.components.map((component, index) => (
                    <div
                      key={component.id}
                      className={`absolute w-6 h-6 rounded cursor-pointer transition-all duration-300 ${
                        selectedComponent === component.id ? 'ring-2 ring-yellow-400' : ''
                      }`}
                      style={{
                        left: `${50 + component.position.x * 20}%`,
                        top: `${50 + component.position.y * 20}%`,
                        backgroundColor: component.type === 'solar_panel' ? '#fbbf24' :
                                       component.type === 'antenna' ? '#ef4444' :
                                       component.type === 'thruster' ? '#8b5cf6' :
                                       component.type === 'sensor' ? '#10b981' : '#6b7280'
                      }}
                      onClick={() => setSelectedComponent(component.id)}
                      title={`${component.type} - ${component.id}`}
                    >
                      <div className="w-full h-full flex items-center justify-center text-xs">
                        {componentTypes.find(t => t.id === component.type)?.icon}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <h3 className="text-xl font-semibold text-white mb-2">Interactive 3D Model</h3>
              <p className="text-gray-400 mb-4">
                {spacecraft.geometry === 'custom' ? 'Custom CAD Model' : 
                 geometryTypes.find(g => g.id === spacecraft.geometry)?.label}
              </p>
              
              <div className="flex justify-center space-x-2 mb-4">
                <div className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded text-sm">
                  Material: {materials.find(m => m.id === spacecraft.material)?.label}
                </div>
                <div className="px-3 py-1 bg-green-600/20 text-green-400 rounded text-sm">
                  Size: {spacecraft.size.toFixed(1)}m
                </div>
                <div className="px-3 py-1 bg-purple-600/20 text-purple-400 rounded text-sm">
                  Components: {spacecraft.components.length}
                </div>
              </div>
            </div>
          </div>

          {/* Controls Overlay */}
          <div className="absolute top-4 right-4 flex space-x-2">
            <button 
              onClick={() => onUpdate({ ...spacecraft, orientation: { x: 0, y: 0, z: 0 } })}
              className="p-2 bg-gray-800/80 text-white rounded hover:bg-gray-700 transition-colors"
              title="Reset View"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="p-2 bg-gray-800/80 text-white rounded hover:bg-gray-700 transition-colors"
              title="Import CAD"
            >
              <Upload className="w-4 h-4" />
            </button>
            <button 
              className="p-2 bg-gray-800/80 text-white rounded hover:bg-gray-700 transition-colors"
              title="Export Model"
            >
              <Download className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setShowAddComponent(true)}
              className="p-2 bg-green-600/80 text-white rounded hover:bg-green-700 transition-colors"
              title="Add Component"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Mesh Info */}
          {spacecraft.mesh && (
            <div className="absolute bottom-4 left-4 bg-gray-800/80 rounded p-2 text-xs text-gray-300">
              <div>Vertices: {spacecraft.mesh.vertices.length / 3}</div>
              <div>Faces: {spacecraft.mesh.faces.length}</div>
            </div>
          )}
        </div>
      </div>

      {/* Configuration Panel */}
      <div className="w-96 p-6 border-l border-gray-700 overflow-y-auto">
        <h2 className="text-xl font-semibold text-white mb-6">Spacecraft Configuration</h2>
        
        {/* Geometry Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-3">Geometry Type</label>
          <div className="space-y-2">
            {geometryTypes.map((type) => (
              <div
                key={type.id}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  spacecraft.geometry === type.id
                    ? 'border-blue-500 bg-blue-500/10'
                    : 'border-gray-600 hover:border-gray-500'
                }`}
                onClick={() => onUpdate({ ...spacecraft, geometry: type.id })}
              >
                <div className="font-medium text-white">{type.label}</div>
                <div className="text-xs text-gray-400">{type.description}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Material Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-3">Primary Material</label>
          <div className="space-y-2">
            {materials.map((material) => (
              <div
                key={material.id}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  spacecraft.material === material.id
                    ? 'border-green-500 bg-green-500/10'
                    : 'border-gray-600 hover:border-gray-500'
                }`}
                onClick={() => onUpdate({ ...spacecraft, material: material.id })}
              >
                <div className="font-medium text-white">{material.label}</div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>σ: {material.conductivity}</span>
                  <span>ρ: {material.density} g/cm³</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Size Control */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Characteristic Size: {spacecraft.size.toFixed(1)} m
          </label>
          <input
            type="range"
            min="0.1"
            max="50"
            step="0.1"
            value={spacecraft.size}
            onChange={(e) => onUpdate({ ...spacecraft, size: parseFloat(e.target.value) })}
            className="w-full bg-gray-700 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>0.1m</span>
            <span>50m</span>
          </div>
        </div>

        {/* Components List */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <label className="block text-sm font-medium text-gray-300">Components</label>
            <button
              onClick={() => setShowAddComponent(true)}
              className="p-1 text-green-400 hover:text-green-300 transition-colors"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
          
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {spacecraft.components.map((component) => (
              <div
                key={component.id}
                className={`p-2 rounded border cursor-pointer transition-all ${
                  selectedComponent === component.id
                    ? 'border-yellow-500 bg-yellow-500/10'
                    : 'border-gray-600 hover:border-gray-500'
                }`}
                onClick={() => setSelectedComponent(component.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span>{componentTypes.find(t => t.id === component.type)?.icon}</span>
                    <span className="text-sm text-white">{component.type}</span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeComponent(component.id);
                    }}
                    className="text-red-400 hover:text-red-300 transition-colors"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Component Properties */}
        {selectedComponent && (
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-300 mb-3">Component Properties</h3>
            {(() => {
              const component = spacecraft.components.find(c => c.id === selectedComponent);
              if (!component) return null;
              
              return (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Position (m)</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['x', 'y', 'z'].map((axis) => (
                        <input
                          key={axis}
                          type="number"
                          step="0.1"
                          value={component.position[axis as keyof typeof component.position]}
                          onChange={(e) => updateComponent(component.id, {
                            position: {
                              ...component.position,
                              [axis]: parseFloat(e.target.value) || 0
                            }
                          })}
                          className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-xs"
                          placeholder={axis.toUpperCase()}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Dimensions (m)</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['width', 'height', 'depth'].map((dim) => (
                        <input
                          key={dim}
                          type="number"
                          step="0.1"
                          min="0.1"
                          value={component.dimensions[dim as keyof typeof component.dimensions]}
                          onChange={(e) => updateComponent(component.id, {
                            dimensions: {
                              ...component.dimensions,
                              [dim]: parseFloat(e.target.value) || 0.1
                            }
                          })}
                          className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-xs"
                          placeholder={dim.charAt(0).toUpperCase()}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Material</label>
                    <select
                      value={component.material}
                      onChange={(e) => updateComponent(component.id, { material: e.target.value })}
                      className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-xs"
                    >
                      {materials.map((material) => (
                        <option key={material.id} value={material.id}>
                          {material.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* Add Component Modal */}
        {showAddComponent && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-gray-800 rounded-lg p-6 w-80">
              <h3 className="text-lg font-semibold text-white mb-4">Add Component</h3>
              <div className="space-y-2">
                {componentTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => addComponent(type.id)}
                    className="w-full p-3 text-left border border-gray-600 rounded hover:border-gray-500 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-lg">{type.icon}</span>
                      <span className="text-white">{type.label}</span>
                    </div>
                  </button>
                ))}
              </div>
              <button
                onClick={() => setShowAddComponent(false)}
                className="w-full mt-4 py-2 bg-gray-700 text-white rounded hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".step,.stp,.iges,.igs,.obj,.stl"
          onChange={handleFileUpload}
          className="hidden"
        />
      </div>
    </div>
  );
};