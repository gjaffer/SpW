import React from 'react';
import { TrendingUp, Zap, Thermometer, Activity } from 'lucide-react';

interface ResultsProps {
  solvers: any;
  solvers: any;
  results: {
    surfaceCharge: number;
    currentDensity: number;
    fieldStrength: number;
    temperature: number;
    radiationDose: number;
    thermalStress: number;
  };
  isRunning: boolean;
  onUpdate: (solvers: any) => void;
  onRunSimulation: () => void;
  onUpdate: (solvers: any) => void;
  onRunSimulation: () => void;
}

export const SimulationResults: React.FC<ResultsProps> = ({ 
  solvers, 
  results, 
  isRunning, 
  onUpdate, 
  onRunSimulation 
}) => {
  const metrics = [
    {
      label: 'Surface Potential',
      value: results.surfaceCharge,
      unit: 'V',
      icon: Zap,
      color: 'blue',
      trend: -2.3,
      description: 'Spacecraft charging relative to plasma'
    },
    {
      label: 'Current Density',
      value: results.currentDensity * 1e9,
      unit: 'nA/m²',
      icon: Activity,
      color: 'green',
      trend: 1.7,
      description: 'Particle collection current'
    },
    {
      label: 'Field Strength',
      value: results.fieldStrength,
      unit: 'V/m',
      icon: TrendingUp,
      color: 'purple',
      trend: 0.8,
      description: 'Electric field around spacecraft'
    },
    {
      label: 'Surface Temperature',
      value: results.temperature,
      unit: 'K',
      icon: Thermometer,
      color: 'orange',
      trend: -0.5,
      description: 'Thermal effects from plasma interaction'
    }
  ];

  // Generate mock time series data
  const generateTimeSeriesData = (baseValue: number, variance: number) => {
    return Array.from({ length: 50 }, (_, i) => ({
      time: i,
      value: baseValue + (Math.random() - 0.5) * variance * 2
    }));
  };

  const timeSeriesData = {
    potential: generateTimeSeriesData(results.surfaceCharge, 2),
    current: generateTimeSeriesData(results.currentDensity * 1e9, 0.5),
    field: generateTimeSeriesData(results.fieldStrength, 20),
    temperature: generateTimeSeriesData(results.temperature, 5)
  };

  return (
    <div className="h-full p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold text-white mb-2">Simulation Results</h2>
        <p className="text-gray-400">Real-time analysis of spacecraft-plasma interactions</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          const colorClasses = {
            blue: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
            green: 'text-green-400 bg-green-500/10 border-green-500/20',
            purple: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
            orange: 'text-orange-400 bg-orange-500/10 border-orange-500/20'
          };

          return (
            <div key={index} className={`rounded-lg p-4 border ${colorClasses[metric.color as keyof typeof colorClasses]}`}>
              <div className="flex items-center justify-between mb-2">
                <Icon className="w-5 h-5" />
                <div className={`text-xs px-2 py-1 rounded ${
                  metric.trend > 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                }`}>
                  {metric.trend > 0 ? '+' : ''}{metric.trend.toFixed(1)}%
                </div>
              </div>
              <div className="text-2xl font-bold text-white mb-1">
                {metric.value.toFixed(metric.unit === 'nA/m²' ? 2 : 1)}
                <span className="text-sm font-normal text-gray-400 ml-1">{metric.unit}</span>
              </div>
              <div className="text-sm font-medium text-gray-300 mb-1">{metric.label}</div>
              <div className="text-xs text-gray-500">{metric.description}</div>
            </div>
          );
        })}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Surface Potential Chart */}
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <h3 className="text-lg font-medium text-white mb-4">Surface Potential vs Time</h3>
          <div className="h-48 bg-gray-900 rounded-lg flex items-center justify-center border border-gray-600">
            <div className="text-center">
              <Activity className="w-12 h-12 text-blue-400 mx-auto mb-2" />
              <p className="text-gray-400 text-sm">Real-time potential monitoring</p>
              <div className="mt-2 text-xs text-gray-500">
                {isRunning ? 'Data streaming...' : 'Simulation paused'}
              </div>
            </div>
          </div>
        </div>

        {/* Current Density Chart */}
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <h3 className="text-lg font-medium text-white mb-4">Current Collection</h3>
          <div className="h-48 bg-gray-900 rounded-lg flex items-center justify-center border border-gray-600">
            <div className="text-center">
              <TrendingUp className="w-12 h-12 text-green-400 mx-auto mb-2" />
              <p className="text-gray-400 text-sm">Particle flux analysis</p>
              <div className="mt-2 text-xs text-gray-500">
                Ion/Electron collection rates
              </div>
            </div>
          </div>
        </div>

        {/* 3D Field Visualization */}
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <h3 className="text-lg font-medium text-white mb-4">Electric Field Distribution</h3>
          <div className="h-48 bg-gray-900 rounded-lg flex items-center justify-center border border-gray-600">
            <div className="text-center">
              <Zap className="w-12 h-12 text-purple-400 mx-auto mb-2" />
              <p className="text-gray-400 text-sm">3D field visualization</p>
              <div className="mt-2 text-xs text-gray-500">
                Interactive field line display
              </div>
            </div>
          </div>
        </div>

        {/* Thermal Analysis */}
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <h3 className="text-lg font-medium text-white mb-4">Thermal Effects</h3>
          <div className="h-48 bg-gray-900 rounded-lg flex items-center justify-center border border-gray-600">
            <div className="text-center">
              <Thermometer className="w-12 h-12 text-orange-400 mx-auto mb-2" />
              <p className="text-gray-400 text-sm">Temperature distribution</p>
              <div className="mt-2 text-xs text-gray-500">
                Plasma heating effects
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Analysis Summary */}
      <div className="mt-6 bg-gray-800 rounded-lg p-4 border border-gray-700">
        <h3 className="text-lg font-medium text-white mb-3">Analysis Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <h4 className="text-sm font-medium text-blue-400 mb-2">Charging Status</h4>
            <p className="text-xs text-gray-400">
              Spacecraft is negatively charged at {Math.abs(results.surfaceCharge).toFixed(1)}V. 
              Equilibrium reached between electron and ion collection.
            </p>
          </div>
          <div>
            <h4 className="text-sm font-medium text-green-400 mb-2">Current Balance</h4>
            <p className="text-xs text-gray-400">
              Net current density of {(results.currentDensity * 1e9).toFixed(2)} nA/m². 
              Dominated by electron collection on sunlit surfaces.
            </p>
          </div>
          <div>
            <h4 className="text-sm font-medium text-orange-400 mb-2">Risk Assessment</h4>
            <p className="text-xs text-gray-400">
              Low risk of electrostatic discharge. Surface potential within 
              acceptable limits for spacecraft operations.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};