import React from 'react';

interface MainContentProps {
  children: React.ReactNode;
}

export const MainContent: React.FC<MainContentProps> = ({ children }) => {
  return (
    <div className="flex-1 bg-gray-900 p-6 overflow-hidden">
      <div className="h-full bg-gray-850 rounded-xl border border-gray-700 shadow-2xl overflow-hidden">
        {children}
      </div>
    </div>
  );
};