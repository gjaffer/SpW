import React from 'react';
import { RotateCcw, Upload, Download, Settings } from 'lucide-react';

interface SpacecraftProps {
  spacecraft: {
    geometry: string;
    material: string;
    size: number;
    orientation: { x: number; y: number; z: number };
  };
  onUpdate: (spacecraft: any) => void;
}

export const SpacecraftViewer: React.FC<SpacecraftProps> = ({ spacecraft, onUpdate }) => {
  const geometryTypes = [
    { id: 'satellite', label: 'Standard Satellite', description: 'Cubic satellite with solar panels' },
    { id: 'probe', label: 'Space Probe', description: 'Cylindrical probe with antenna' },
    { id: 'station', label: 'Space Station', description: 'Complex multi-module structure' },
    { id: 'custom', label: 'Custom CAD', description: 'Import custom 3D model' }
  ];

  const materials = [
    { id: 'aluminum', label: 'Aluminum Alloy', conductivity: 'High', charging: 'Low' },
    { id: 'carbon', label: 'Carbon Fiber', conductivity: 'Medium', charging: 'Medium' },
    { id: 'kapton', label: 'Kapton Film', conductivity: 'Low', charging: 'High' },
    { id: 'gold', label: 'Gold Plated', conductivity: 'Very High', charging: 'Very Low' }
  ];

  return (
    <div className="h-full flex">
      {/* 3D Viewer */}
      <div className="flex-1 p-6">
        <div className="bg-black rounded-lg h-full relative border border-gray-600">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg mx-auto mb-4 flex items-center justify-center">
                <div className="w-16 h-16 bg-gray-300 rounded transform rotate-45"></div>
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">3D Spacecraft Model</h3>
              <p className="text-gray-400 mb-4">Interactive visualization will be rendered here</p>
              <div className="flex justify-center space-x-2">
                <button className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors">
                  Rotate
                </button>
                <button className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700 transition-colors">
                  Zoom
                </button>
                <button className="px-3 py-1 bg-purple-600 text-white rounded text-sm hover:bg-purple-700 transition-colors">
                  Pan
                </button>
              </div>
            </div>
          </div>

          {/* Controls Overlay */}
          <div className="absolute top-4 right-4 flex space-x-2">
            <button className="p-2 bg-gray-800 text-white rounded hover:bg-gray-700 transition-colors">
              <RotateCcw className="w-4 h-4" />
            </button>
            <button className="p-2 bg-gray-800 text-white rounded hover:bg-gray-700 transition-colors">
              <Upload className="w-4 h-4" />
            </button>
            <button className="p-2 bg-gray-800 text-white rounded hover:bg-gray-700 transition-colors">
              <Download className="w-4 h-4" />
            </button>
            <button className="p-2 bg-gray-800 text-white rounded hover:bg-gray-700 transition-colors">
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Configuration Panel */}
      <div className="w-80 p-6 border-l border-gray-700">
        <h2 className="text-xl font-semibold text-white mb-6">Spacecraft Configuration</h2>
        
        {/* Geometry Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-3">Geometry Type</label>
          <div className="space-y-2">
            {geometryTypes.map((type) => (
              <div
                key={type.id}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  spacecraft.geometry === type.id
                    ? 'border-blue-500 bg-blue-500/10'
                    : 'border-gray-600 hover:border-gray-500'
                }`}
                onClick={() => onUpdate({ ...spacecraft, geometry: type.id })}
              >
                <div className="font-medium text-white">{type.label}</div>
                <div className="text-xs text-gray-400">{type.description}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Material Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-3">Surface Material</label>
          <div className="space-y-2">
            {materials.map((material) => (
              <div
                key={material.id}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  spacecraft.material === material.id
                    ? 'border-green-500 bg-green-500/10'
                    : 'border-gray-600 hover:border-gray-500'
                }`}
                onClick={() => onUpdate({ ...spacecraft, material: material.id })}
              >
                <div className="font-medium text-white">{material.label}</div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Conductivity: {material.conductivity}</span>
                  <span>Charging: {material.charging}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Size Control */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Characteristic Size: {spacecraft.size.toFixed(1)} m
          </label>
          <input
            type="range"
            min="0.5"
            max="10"
            step="0.1"
            value={spacecraft.size}
            onChange={(e) => onUpdate({ ...spacecraft, size: parseFloat(e.target.value) })}
            className="w-full bg-gray-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Orientation Controls */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-3">Orientation (degrees)</label>
          <div className="space-y-3">
            {['x', 'y', 'z'].map((axis) => (
              <div key={axis}>
                <label className="block text-xs text-gray-400 mb-1">
                  {axis.toUpperCase()}-axis: {spacecraft.orientation[axis as keyof typeof spacecraft.orientation]}°
                </label>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  step="1"
                  value={spacecraft.orientation[axis as keyof typeof spacecraft.orientation]}
                  onChange={(e) => onUpdate({
                    ...spacecraft,
                    orientation: {
                      ...spacecraft.orientation,
                      [axis]: parseInt(e.target.value)
                    }
                  })}
                  className="w-full bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};