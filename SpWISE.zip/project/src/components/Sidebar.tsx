import React from 'react';
import { 
  Box, Gauge, BarChart3, CloudSun, Brain, Map, Download, 
  Zap, Thermometer, Shield, Cpu 
} from 'lucide-react';
import { SimulationState } from '../types';

interface SidebarProps {
  activePanel: string;
  onPanelChange: (panel: string) => void;
  simulationState: SimulationState;
}

export const Sidebar: React.FC<SidebarProps> = ({ activePanel, onPanelChange, simulationState }) => {
  const panels = [
    {
      id: 'spacecraft',
      label: 'Spacecraft',
      icon: Box,
      description: '3D Modeling & CAD',
      color: 'blue'
    },
    {
      id: 'environment',
      label: 'Environment',
      icon: Gauge,
      description: 'Plasma Parameters',
      color: 'green'
    },
    {
      id: 'solvers',
      label: 'Multi-Physics',
      icon: Cpu,
      description: 'PIC/FEM/Thermal',
      color: 'purple'
    },
    {
      id: 'weather',
      label: 'Space Weather',
      icon: CloudSun,
      description: 'Real-time Data',
      color: 'orange'
    },
    {
      id: 'ai',
      label: 'AI Assistant',
      icon: Brain,
      description: 'Fast Simulation',
      color: 'pink'
    },
    {
      id: 'mission',
      label: 'Mission Planner',
      icon: Map,
      description: 'Orbital Analysis',
      color: 'indigo'
    },
    {
      id: 'export',
      label: 'Data Export',
      icon: Download,
      description: 'Results & Reports',
      color: 'gray'
    }
  ];

  const getStatusColor = (panelId: string) => {
    switch (panelId) {
      case 'spacecraft':
        return simulationState.spacecraft.components.length > 0 ? 'green' : 'yellow';
      case 'environment':
        return simulationState.environment.plasmaDensity > 0 ? 'green' : 'red';
      case 'solvers':
        const enabledSolvers = Object.values(simulationState.solvers).filter(s => s.enabled).length;
        return enabledSolvers > 2 ? 'green' : enabledSolvers > 0 ? 'yellow' : 'red';
      case 'weather':
        return 'green'; // Assume weather data is available
      case 'ai':
        return simulationState.ai.fastMode ? 'green' : 'gray';
      default:
        return 'gray';
    }
  };

  return (
    <div className="w-72 bg-gray-800 border-r border-gray-700 flex flex-col">
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-lg font-semibold text-white mb-2">Control Panels</h2>
        <p className="text-sm text-gray-400">Configure simulation parameters and solvers</p>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {panels.map((panel) => {
          const Icon = panel.icon;
          const isActive = activePanel === panel.id;
          const statusColor = getStatusColor(panel.id);
          
          return (
            <button
              key={panel.id}
              onClick={() => onPanelChange(panel.id)}
              className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-all ${
                isActive
                  ? `bg-${panel.color}-600 text-white shadow-lg`
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                <div className={`absolute -top-1 -right-1 w-2 h-2 rounded-full bg-${statusColor}-400`} />
              </div>
              <div className="text-left flex-1">
                <div className="font-medium">{panel.label}</div>
                <div className="text-xs opacity-80">{panel.description}</div>
              </div>
            </button>
          );
        })}
      </nav>

      {/* Quick Status Panel */}
      <div className="p-4 border-t border-gray-700">
        <div className="bg-gray-700 rounded-lg p-3">
          <h3 className="text-sm font-medium text-white mb-3 flex items-center">
            <BarChart3 className="w-4 h-4 mr-2" />
            System Status
          </h3>
          
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Zap className="w-3 h-3 text-blue-400" />
                <span className="text-gray-400">Surface Charge:</span>
              </div>
              <span className="text-blue-400 font-medium">
                {simulationState.results.surfaceCharge.toFixed(1)} V
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Thermometer className="w-3 h-3 text-orange-400" />
                <span className="text-gray-400">Temperature:</span>
              </div>
              <span className="text-orange-400 font-medium">
                {simulationState.results.temperature.toFixed(0)} K
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Shield className="w-3 h-3 text-green-400" />
                <span className="text-gray-400">Radiation:</span>
              </div>
              <span className="text-green-400 font-medium">
                {simulationState.results.radiationDose.toFixed(1)} mrad/day
              </span>
            </div>
          </div>

          {/* Solver Status */}
          <div className="mt-3 pt-3 border-t border-gray-600">
            <div className="text-xs text-gray-400 mb-2">Active Solvers:</div>
            <div className="flex flex-wrap gap-1">
              {Object.entries(simulationState.solvers).map(([key, solver]) => (
                <div
                  key={key}
                  className={`px-2 py-1 rounded text-xs ${
                    solver.enabled 
                      ? 'bg-green-600/20 text-green-400' 
                      : 'bg-gray-600/20 text-gray-500'
                  }`}
                >
                  {key.toUpperCase()}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};