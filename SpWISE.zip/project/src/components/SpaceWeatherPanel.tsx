import React, { useState } from 'react';
import { CloudSun, Sun, Zap, AlertTriangle, TrendingUp, RefreshCw } from 'lucide-react';

interface SpaceWeatherProps {
  onEnvironmentUpdate: (environment: any) => void;
}

export const SpaceWeatherPanel: React.FC<SpaceWeatherProps> = ({ onEnvironmentUpdate }) => {
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [isLoading, setIsLoading] = useState(false);

  const solarData = {
    solarWindSpeed: 425,
    protonDensity: 6.2,
    magneticField: 8.3,
    kpIndex: 2.3,
    apIndex: 12,
    f107: 128.5,
    sunspotNumber: 45
  };

  const alerts = [
    {
      level: 'warning',
      type: 'Geomagnetic Storm',
      message: 'Minor geomagnetic storm conditions observed',
      time: '2 hours ago'
    },
    {
      level: 'info',
      type: 'Solar Wind',
      message: 'Elevated solar wind speed detected',
      time: '4 hours ago'
    }
  ];

  const forecast = [
    { date: 'Today', kp: 2.3, condition: 'Quiet', risk: 'Low' },
    { date: 'Tomorrow', kp: 3.1, condition: 'Unsettled', risk: 'Medium' },
    { date: 'Day 3', kp: 4.2, condition: 'Active', risk: 'High' },
    { date: 'Day 4', kp: 2.8, condition: 'Quiet', risk: 'Low' },
    { date: 'Day 5', kp: 1.9, condition: 'Quiet', risk: 'Low' }
  ];

  const handleRefresh = async () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLastUpdate(new Date());
      setIsLoading(false);
    }, 2000);
  };

  const applyRealtimeData = () => {
    const environment = {
      plasmaDensity: solarData.protonDensity * 1e6,
      temperature: 100000,
      velocity: solarData.solarWindSpeed,
      magneticField: solarData.magneticField,
      solarActivity: Math.min(solarData.kpIndex / 9, 1)
    };
    onEnvironmentUpdate(environment);
  };

  return (
    <div className="h-full p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-white mb-2">Space Weather</h2>
          <p className="text-gray-400">Real-time space environment monitoring</p>
        </div>
        <button
          onClick={handleRefresh}
          disabled={isLoading}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100%-6rem)]">
        {/* Current Conditions */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-white mb-4">Current Conditions</h3>
          
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <Sun className="w-5 h-5 text-yellow-400" />
                <span className="font-medium text-white">Solar Activity</span>
              </div>
              <div className="text-sm text-gray-400">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">F10.7 Flux:</span>
                <span className="text-yellow-400">{solarData.f107} sfu</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Sunspot Number:</span>
                <span className="text-yellow-400">{solarData.sunspotNumber}</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <div className="flex items-center space-x-2 mb-3">
              <CloudSun className="w-5 h-5 text-blue-400" />
              <span className="font-medium text-white">Solar Wind</span>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Speed:</span>
                <span className="text-blue-400">{solarData.solarWindSpeed} km/s</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Proton Density:</span>
                <span className="text-blue-400">{solarData.protonDensity} /cm³</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Magnetic Field:</span>
                <span className="text-blue-400">{solarData.magneticField} nT</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <div className="flex items-center space-x-2 mb-3">
              <Zap className="w-5 h-5 text-purple-400" />
              <span className="font-medium text-white">Geomagnetic</span>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Kp Index:</span>
                <span className="text-purple-400">{solarData.kpIndex}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Ap Index:</span>
                <span className="text-purple-400">{solarData.apIndex}</span>
              </div>
            </div>
          </div>

          <button
            onClick={applyRealtimeData}
            className="w-full py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
          >
            Apply Real-time Data
          </button>
        </div>

        {/* Alerts & Warnings */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-white mb-4">Alerts & Warnings</h3>
          
          <div className="space-y-3">
            {alerts.map((alert, index) => (
              <div
                key={index}
                className={`rounded-lg p-4 border ${
                  alert.level === 'warning'
                    ? 'border-yellow-500/30 bg-yellow-500/10'
                    : 'border-blue-500/30 bg-blue-500/10'
                }`}
              >
                <div className="flex items-start space-x-2">
                  <AlertTriangle
                    className={`w-5 h-5 mt-0.5 ${
                      alert.level === 'warning' ? 'text-yellow-400' : 'text-blue-400'
                    }`}
                  />
                  <div className="flex-1">
                    <div className="font-medium text-white">{alert.type}</div>
                    <div className="text-sm text-gray-300 mt-1">{alert.message}</div>
                    <div className="text-xs text-gray-500 mt-1">{alert.time}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Activity Levels */}
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <h4 className="font-medium text-white mb-3">Activity Levels</h4>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Solar Activity</span>
                  <span className="text-yellow-400">Moderate</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div className="bg-yellow-400 h-2 rounded-full" style={{ width: '60%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Geomagnetic</span>
                  <span className="text-green-400">Quiet</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div className="bg-green-400 h-2 rounded-full" style={{ width: '30%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Radio Blackout</span>
                  <span className="text-blue-400">None</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div className="bg-blue-400 h-2 rounded-full" style={{ width: '10%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Forecast */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-white mb-4">5-Day Forecast</h3>
          
          <div className="space-y-3">
            {forecast.map((day, index) => (
              <div
                key={index}
                className="bg-gray-800 rounded-lg p-4 border border-gray-700"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-white">{day.date}</span>
                  <div className={`px-2 py-1 rounded text-xs ${
                    day.risk === 'Low' ? 'bg-green-500/20 text-green-400' :
                    day.risk === 'Medium' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {day.risk} Risk
                  </div>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Kp: {day.kp}</span>
                  <span className="text-gray-300">{day.condition}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Historical Trends */}
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <div className="flex items-center space-x-2 mb-3">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="font-medium text-white">Trends</span>
            </div>
            <div className="h-32 bg-gray-900 rounded-lg flex items-center justify-center border border-gray-600">
              <div className="text-center">
                <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-2" />
                <p className="text-gray-400 text-sm">Kp Index Trend</p>
                <div className="text-xs text-gray-500">Last 24 hours</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};