import React from 'react';
import { Play, Pause, Download, Settings, Satellite, Zap, AlertTriangle } from 'lucide-react';
import { SimulationState, SpaceWeatherData } from '../types';

interface HeaderProps {
  simulationState: SimulationState;
  onToggleSimulation: () => void;
  spaceWeatherData: SpaceWeatherData | null;
}

export const Header: React.FC<HeaderProps> = ({ simulationState, onToggleSimulation, spaceWeatherData }) => {
  const getSpaceWeatherStatus = () => {
    if (!spaceWeatherData) return { level: 'unknown', color: 'gray' };
    
    const kp = spaceWeatherData.geomagnetic.kpIndex;
    if (kp < 3) return { level: 'quiet', color: 'green' };
    if (kp < 5) return { level: 'unsettled', color: 'yellow' };
    if (kp < 7) return { level: 'active', color: 'orange' };
    return { level: 'storm', color: 'red' };
  };

  const weatherStatus = getSpaceWeatherStatus();

  return (
    <header className="bg-gray-800 border-b border-gray-700 px-6 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Satellite className="w-8 h-8 text-blue-400" />
              <Zap className="w-3 h-3 text-yellow-400 absolute -top-1 -right-1" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">SpaceWISE</h1>
              <p className="text-xs text-gray-400">Web-based Intelligent Solver for Space Environment</p>
            </div>
          </div>

          {/* Space Weather Indicator */}
          <div className="flex items-center space-x-2 px-3 py-1 bg-gray-700 rounded-lg">
            <div className={`w-2 h-2 rounded-full bg-${weatherStatus.color}-400`} />
            <span className="text-xs text-gray-300">
              Space Weather: {weatherStatus.level.charAt(0).toUpperCase() + weatherStatus.level.slice(1)}
            </span>
            {spaceWeatherData && (
              <span className="text-xs text-gray-500">
                Kp: {spaceWeatherData.geomagnetic.kpIndex.toFixed(1)}
              </span>
            )}
          </div>

          {/* AI Mode Indicator */}
          {simulationState.ai.fastMode && (
            <div className="flex items-center space-x-2 px-3 py-1 bg-purple-600/20 border border-purple-500/30 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
              <span className="text-xs text-purple-300">AI Fast Mode</span>
              <span className="text-xs text-purple-400">
                {(simulationState.ai.confidence * 100).toFixed(0)}% confidence
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-4">
          {/* Simulation Status */}
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2 text-sm">
              <div className={`w-2 h-2 rounded-full ${
                simulationState.isRunning ? 'bg-green-400 animate-pulse' : 'bg-gray-500'
              }`} />
              <span className="text-gray-300">
                {simulationState.isRunning ? 'Computing...' : 'Ready'}
              </span>
            </div>

            {/* Mode Indicator */}
            <div className="text-xs text-gray-400 px-2 py-1 bg-gray-700 rounded">
              {simulationState.mode === 'realtime' ? 'Real-time' :
               simulationState.mode === 'batch' ? 'Batch' : 'AI Fast'}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="hidden lg:flex items-center space-x-4 text-xs">
            <div className="text-center">
              <div className="text-blue-400 font-medium">
                {simulationState.results.surfaceCharge.toFixed(1)}V
              </div>
              <div className="text-gray-500">Charge</div>
            </div>
            <div className="text-center">
              <div className="text-green-400 font-medium">
                {simulationState.results.temperature.toFixed(0)}K
              </div>
              <div className="text-gray-500">Temp</div>
            </div>
            <div className="text-center">
              <div className="text-orange-400 font-medium">
                {simulationState.results.radiationDose.toFixed(1)}
              </div>
              <div className="text-gray-500">mrad/day</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <button
              onClick={onToggleSimulation}
              disabled={simulationState.isRunning}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all ${
                simulationState.isRunning
                  ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                  : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
            >
              {simulationState.isRunning ? (
                <>
                  <div className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                  <span>Running</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  <span>Run Simulation</span>
                </>
              )}
            </button>

            <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors">
              <Download className="w-5 h-5" />
            </button>

            <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Alerts Bar */}
      {simulationState.ai.recommendations.length > 0 && (
        <div className="mt-2 flex items-center space-x-2 px-4 py-2 bg-yellow-600/10 border border-yellow-500/30 rounded-lg">
          <AlertTriangle className="w-4 h-4 text-yellow-400" />
          <span className="text-sm text-yellow-300">
            {simulationState.ai.recommendations[0].message}
          </span>
          <button className="text-xs text-yellow-400 hover:text-yellow-300 underline">
            View All ({simulationState.ai.recommendations.length})
          </button>
        </div>
      )}
    </header>
  );
};