import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MainContent } from './components/MainContent';
import { SpacecraftModeler } from './components/SpacecraftModeler';
import { EnvironmentPanel } from './components/EnvironmentPanel';
import { SimulationResults } from './components/SimulationResults';
import { SpaceWeatherPanel } from './components/SpaceWeatherPanel';
import { SimulationEngine } from './core/SimulationEngine';
import { SpaceWeatherAPI } from './services/SpaceWeatherAPI';
import { SimulationState, SpacecraftConfig, EnvironmentConfig } from './types';

function App() {
  const [activePanel, setActivePanel] = useState<string>('spacecraft');
  const [simulationState, setSimulationState] = useState<SimulationState>({
    isRunning: false,
    mode: 'realtime',
    spacecraft: {
      geometry: 'satellite',
      material: 'aluminum',
      size: 2.5,
      orientation: { x: 0, y: 0, z: 0 },
      components: [],
      mesh: null
    },
    environment: {
      plasmaDensity: 1e6,
      temperature: 1000,
      velocity: 400,
      magneticField: 50,
      solarActivity: 0.5,
      location: 'LEO',
      altitude: 400
    },
    solvers: {
      pic: { enabled: true, timestep: 1e-9, particles: 10000 },
      fem: { enabled: true, elements: 500, convergence: 1e-6 },
      thermal: { enabled: true, conductivity: 200, emissivity: 0.8 },
      radiation: { enabled: true, shielding: 2.0, materials: ['aluminum'] }
    },
    results: {
      surfaceCharge: -12.5,
      currentDensity: 2.3e-9,
      fieldStrength: 150,
      temperature: 285,
      radiationDose: 0.5,
      thermalStress: 25
    },
    ai: {
      fastMode: false,
      confidence: 0.95,
      recommendations: []
    }
  });

  const [spaceWeatherData, setSpaceWeatherData] = useState(null);
  const [simulationEngine] = useState(new SimulationEngine());

  useEffect(() => {
    // Initialize space weather data feed
    const initializeSpaceWeather = async () => {
      try {
        const data = await SpaceWeatherAPI.getCurrentConditions();
        setSpaceWeatherData(data);
      } catch (error) {
        console.error('Failed to fetch space weather data:', error);
      }
    };

    initializeSpaceWeather();
    
    // Set up real-time updates
    const interval = setInterval(initializeSpaceWeather, 300000); // 5 minutes
    return () => clearInterval(interval);
  }, []);

  const updateSimulationState = (updates: Partial<SimulationState>) => {
    setSimulationState(prev => ({
      ...prev,
      ...updates
    }));
  };

  const handleRunSimulation = async () => {
    updateSimulationState({ isRunning: true });
    
    try {
      const results = await simulationEngine.runSimulation(simulationState);
      updateSimulationState({ 
        isRunning: false,
        results: results
      });
    } catch (error) {
      console.error('Simulation failed:', error);
      updateSimulationState({ isRunning: false });
    }
  };

  const renderActivePanel = () => {
    switch (activePanel) {
      case 'spacecraft':
        return (
          <SpacecraftModeler
            spacecraft={simulationState.spacecraft}
            onUpdate={(spacecraft) => updateSimulationState({ spacecraft })}
          />
        );
      case 'environment':
        return (
          <EnvironmentPanel
            environment={simulationState.environment}
            spaceWeatherData={spaceWeatherData}
            onUpdate={(environment) => updateSimulationState({ environment })}
          />
        );
      case 'solvers':
        return (
          <SimulationResults
            solvers={simulationState.solvers}
            results={simulationState.results}
            isRunning={simulationState.isRunning}
            onUpdate={(solvers) => updateSimulationState({ solvers })}
            onRunSimulation={handleRunSimulation}
          />
        );
      case 'weather':
        return (
          <SpaceWeatherPanel
            data={spaceWeatherData}
            onEnvironmentUpdate={(environment) => updateSimulationState({ environment })}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Header 
        simulationState={simulationState}
        onToggleSimulation={handleRunSimulation}
        spaceWeatherData={spaceWeatherData}
      />
      
      <div className="flex h-[calc(100vh-4rem)]">
        <Sidebar 
          activePanel={activePanel}
          onPanelChange={setActivePanel}
          simulationState={simulationState}
        />
        
        <div className="flex-1 flex">
          <MainContent>
            {renderActivePanel()}
          </MainContent>
        </div>
      </div>
    </div>
  );
}

export default App;