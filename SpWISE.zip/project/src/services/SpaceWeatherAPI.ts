import { SpaceWeatherData, SolarFlare } from '../types';

export class SpaceWeatherAPI {
  private static readonly BASE_URL = 'https://services.swpc.noaa.gov/json';
  private static readonly BACKUP_URL = 'https://api.nasa.gov/DONKI';
  
  static async getCurrentConditions(): Promise<SpaceWeatherData> {
    try {
      // In a real implementation, this would fetch from actual APIs
      // For demo purposes, we'll return simulated data
      return this.getSimulatedData();
    } catch (error) {
      console.error('Failed to fetch space weather data:', error);
      return this.getSimulatedData();
    }
  }
  
  private static getSimulatedData(): SpaceWeatherData {
    const now = new Date();
    
    return {
      solarWind: {
        speed: 400 + Math.random() * 200, // 400-600 km/s
        density: 5 + Math.random() * 10, // 5-15 particles/cm³
        temperature: 100000 + Math.random() * 200000, // 100k-300k K
        magneticField: {
          bx: (Math.random() - 0.5) * 20,
          by: (Math.random() - 0.5) * 20,
          bz: (Math.random() - 0.5) * 20
        }
      },
      geomagnetic: {
        kpIndex: Math.random() * 9,
        apIndex: Math.random() * 400,
        dstIndex: -50 + Math.random() * 100
      },
      solar: {
        f107: 70 + Math.random() * 200,
        sunspotNumber: Math.floor(Math.random() * 200),
        solarFlares: this.generateSolarFlares()
      },
      radiation: {
        protonFlux: Math.random() * 1000,
        electronFlux: Math.random() * 10000,
        cosmicRays: 100 + Math.random() * 50
      },
      timestamp: now
    };
  }
  
  private static generateSolarFlares(): SolarFlare[] {
    const flares: SolarFlare[] = [];
    const numFlares = Math.floor(Math.random() * 3);
    
    for (let i = 0; i < numFlares; i++) {
      const classes = ['A', 'B', 'C', 'M', 'X'];
      const flareClass = classes[Math.floor(Math.random() * classes.length)];
      const intensity = Math.random() * 9 + 1;
      
      flares.push({
        class: `${flareClass}${intensity.toFixed(1)}`,
        intensity,
        timestamp: new Date(Date.now() - Math.random() * 86400000), // Last 24 hours
        duration: Math.random() * 3600 // Up to 1 hour
      });
    }
    
    return flares;
  }
  
  static async getHistoricalData(startDate: Date, endDate: Date): Promise<SpaceWeatherData[]> {
    // Simulate historical data retrieval
    const data: SpaceWeatherData[] = [];
    const current = new Date(startDate);
    
    while (current <= endDate) {
      data.push({
        ...this.getSimulatedData(),
        timestamp: new Date(current)
      });
      current.setHours(current.getHours() + 1);
    }
    
    return data;
  }
  
  static async getForecast(days: number = 5): Promise<SpaceWeatherData[]> {
    // Simulate forecast data
    const forecast: SpaceWeatherData[] = [];
    const now = new Date();
    
    for (let i = 0; i < days * 24; i++) {
      const forecastTime = new Date(now.getTime() + i * 3600000);
      forecast.push({
        ...this.getSimulatedData(),
        timestamp: forecastTime
      });
    }
    
    return forecast;
  }
}